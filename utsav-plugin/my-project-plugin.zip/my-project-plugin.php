<?php
/**
 * Plugin Name: Utsav Plugin
 * * Description: Handles Utsav's requirements with this plugin.
 */

 // Remove the admin bar from the front end
add_filter( 'show_admin_bar', '__return_false' );